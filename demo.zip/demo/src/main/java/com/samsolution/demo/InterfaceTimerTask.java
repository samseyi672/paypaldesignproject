package com.samsolution.demo;

public interface InterfaceTimerTask implement TimerTask {

}
