package com.samsolution.demo;

import java.io.IOException;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import scala.inline;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(DemoApplication.class, args);
		Scanner scanner =   new Scanner(System.in);
		Scanner scanner2 =   new Scanner(System.in);
		System.out.println("Enter  your twits or any  data and search  twitter.\n This will produce data for  kafka if it  is  installed");
		String  twits =  scanner.nextLine()  ;
		System.out.println("Type  1 if you  want  to  see how  data  is  being  packed  from twitter");
		 int  datpacked   =     scanner2.nextInt() ; 
		new TwitterProducer().run(twits,datpacked)  ; // push data  to  kafka
		//consume from  kafka into  elasticsearch
	  TwitterConsumer  twitConsmer  =  new  TwitterConsumer() ;
	 System.out.println("With  internet connection , if kafka  is installed  on the  machine , type \"y\" or \"n\" to produce and consume twitter data  from kafka into elasticsearch ");
	  String  input  =   scanner.nextLine() ;
	      while(true){
		   if(input.equals("y")) {
	         twitConsmer.runconsumerDataFromKafkaIntoOnlineElasticSearch();  
	         System.out.println("do you  want  to  quit....type y or  n"); 
		      input  =  scanner.nextLine()  ;
		  if(input.equals("n")) {
			  System.out.println("thank you");
			  System.exit(0);  
		         }
		   } else if(input.equals("n")) {
			   System.out.println("you  are connecting  directly to  elasticsearch  online and kafka");
			   System.out.println("Enter  your  twits from twiter ");
			   String  search  =  scanner.nextLine()  ;
			   twitConsmer.run(search);  //  search online  elasticsearch engine
			  System.out.println("do you  want  to  quit....type y or  n"); 
			      input  =  scanner.nextLine()  ;
			  if(input.equals("n")) {
				  System.out.println("thank you");
				  System.exit(0);  
			  }
		   }
      System.out.println("With  internet connection , if kafka  is installed  on the  machine , type \"y\" or \"n\" to produce and consume twitter data  from kafka into elasticsearch "); 
           input  = scanner.nextLine()  ;
	      }
	  
		
	}

}
