package com.samsolution.demo;

import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;
import java.util.Scanner;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.index.IndexRequest;
//import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestClientBuilder.HttpClientConfigCallback;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonParser;

public class TwitterConsumer {
	
	//https://vkcc9l70cm:qntklyk35x@analytic-8563196438.eu-central-1.bonsaisearch.net:443
	// this  is from my bonsai  account , online  elasticsearch  
private  String  hostname  = "analytic-8563196438.eu-central-1.bonsaisearch.net:443"  ;
private String password  = "qntklyk35x"  ;
private String  username    = "vkcc9l70cm"  ; 
private CredentialsProvider provider  =  null  ;
private static  Logger  logger  =  LoggerFactory.getLogger(TwitterConsumer.class.getName())  ;

   public RestHighLevelClient  createClient () {
	 provider  =   new  BasicCredentialsProvider();
	 provider.setCredentials(AuthScope.ANY,new UsernamePasswordCredentials(username, password));
	 RestClientBuilder builder =  RestClient.builder(new HttpHost(hostname,443,"https")) 
			 .setHttpClientConfigCallback(new HttpClientConfigCallback() {
				
				@Override
				public HttpAsyncClientBuilder customizeHttpClient(HttpAsyncClientBuilder arg0) {
					// TODO Auto-generated method stub
					return  arg0.setDefaultCredentialsProvider(provider);
				}
			});
	 RestHighLevelClient client   = new  RestHighLevelClient(builder) ;	 
	           return  client ;
         }
   //  searching with  online elasticsearch 
   public void run(String search) throws IOException {
	    //String  search = null ;
	    String jsonString = null  ;
	    String  id  =  null;
	    RestHighLevelClient client   =null ;
	  IndexRequest indexRequest =null  ;
	  IndexResponse  indexResponse =  null;
	 // System.out.println("Enter the data to  search for in twitter or  -1  to  end :");
	 // search  = input.nextLine()  ;
	    while(true) {
	    	if(search.equals("-1") || search.equals("") || search.equals(" ")) {
		             break  ;         	
		            }	    	
	    	 jsonString  = "{"+search+"}"; 
	    	 client  =  this.createClient()  ;
	    	 indexRequest =  new IndexRequest("twitter","tweets")
	   			  .source(jsonString,XContentType.JSON);
	    	 indexResponse = client.index(indexRequest, RequestOptions.DEFAULT);
	    	   id  =  indexResponse.getId()  ; 
	    String result  =  indexResponse.getResult().getLowercase() ;
	    	 logger.info(id);
	    	 logger.info(result);
	   //System.out.println("Enter the data to  search for in twitter or  -1  to  end :");
	             // search  = input.nextLine()  ;   
	              }
	         client.close();       
            }
   public void   runconsumerDataFromKafkaIntoOnlineElasticSearch() throws IOException {
	   RestHighLevelClient   client  =  this.createClient()  ;  //  connect to  online  elasticsearch
	   KafkaConsumer<String,String> consumer  =  createConsumer("twitter_tweets")  ;// that  input  is the topic
	     while(true) {
	 ConsumerRecords<String,String>  records  =  consumer.poll(Duration.ofMillis(100))  ;
	   for (ConsumerRecord<String,String> record : records) {
		  // String  id  = record.topic()+"_"+record.partition()+"_"+record.offset()  ;  
		   String  id   = extractIdFromTweets(record.value()) ;//twitter  feeds specific id  ;
		//this  is where  we insert  data that we pack  from kafka into elasticsearch 
		  IndexRequest indexRequest =  new IndexRequest("twitter","tweets",id) // to  make  consumer idempotent
		   			  .source(record.value(),XContentType.JSON);
		    IndexResponse	 indexResponse = client.index(indexRequest, RequestOptions.DEFAULT);
		    	// String  id  =  indexResponse.getId()  ;
		    	 logger.info(id);
		    	 try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}   //  introduce a short delay
	            }
	     }
	        client.close();  
                  }
    public KafkaConsumer<String, String> createConsumer(String topic){
    	 String  bootstrapserver  = "127.0.0.1:9091" ;
    	 String  grpId  = ""  ;
    	 //String topic = "" ;
    	Properties  prop =  new Properties(); 
    	//setting  consumer  configuration 
    	prop.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,bootstrapserver)  ;
    	prop.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
    	prop.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName())  ;
    	prop.setProperty(ConsumerConfig.GROUP_ID_CONFIG,grpId)  ;
    	prop.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earlest")  ;
        KafkaConsumer<String,String> consumer  = 	new KafkaConsumer<>(prop);
        consumer.subscribe(Arrays.asList(topic));      
    	return  consumer   ;
           }
   
    /* public static void main(String[] args) throws IOException {
		TwitterConsumer cons =  new  TwitterConsumer() ;
		String  search  = null ;
		Scanner  input =  new Scanner(System.in) ;
		System.out.println("Enter the data to  search for in twitter or  -1  to  end :");
         search  = input.nextLine()  ;
         while(true) {
        	 if(search == null || search == "" || search == " " || search == "-1") {
                 break  ;
              }
        	 cons.run(search) ;
        System.out.println("Enter the data to  search for in twitter or  -1  to  end :");
             search  = input.nextLine()  ;
                 }
	         }*/
    
  public  String  extractIdFromTweets(String  tweetjson){
	  JsonParser parser  =  new JsonParser() ;  //gson  library 
    	 return parser.parse(tweetjson).getAsJsonObject().get("id_str").getAsString() ;
    }
}



























































































